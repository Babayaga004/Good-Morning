/* ==========================================================================
   GOOD MORNING POPUP FLOOD — script
   Click the link -> screen fills with cat-photo popups
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {

  const landing = document.getElementById('landing');
  const triggerBtn = document.getElementById('triggerBtn');
  const popupLayer = document.getElementById('popupLayer');
  const cleanupBtn = document.getElementById('cleanupBtn');
  const popupTemplate = document.getElementById('popupTemplate');

  /* Silly captions — baked into the cat photo itself via the cataas.com
     "says" endpoint, so the text is printed right on the picture. */
  const CAPTIONS = [
    'Good Morning!',
    'Meow-ning!',
    'Rise and Shine!',
    'Purr-fect Morning!',
    'Wakey Wakey!',
    'Hello Sunshine!',
    'Top of the Morning!',
    'Good Morning Bestie!',
    'Cat Says Good Morning!',
    'Morning Vibes Only!',
  ];

  function randomCaption() {
    return CAPTIONS[Math.floor(Math.random() * CAPTIONS.length)];
  }

  /* Your own uploaded silly cat photos live here. Drop more files into
     assets/cats/ and add their filenames to this list to include them. */
  const LOCAL_CATS = [
    'assets/cats/silly-cat-1.png',
  ];

  function catImageUrl(caption, seed) {
    // cataas.com bakes the caption directly onto a random cat photo.
    // The seed query param busts the cache so each popup gets a fresh image.
    const encoded = encodeURIComponent(caption);
    return `https://cataas.com/cat/says/${encoded}?fontSize=42&fontColor=white&width=320&height=300&_=${seed}`;
  }

  function pickImageSrc(caption, seed) {
    // Mostly show your own uploaded cats; occasionally mix in a random
    // online cat for variety. Adjust the 0.7 to change the ratio.
    if (LOCAL_CATS.length > 0 && Math.random() < 0.7) {
      return LOCAL_CATS[Math.floor(Math.random() * LOCAL_CATS.length)];
    }
    return catImageUrl(caption, seed);
  }

  const isSmallScreen = window.matchMedia('(max-width: 600px)').matches;
  const TOTAL_POPUPS = isSmallScreen ? 24 : 44;
  const BOX_W = isSmallScreen ? 160 : 220;
  const BOX_H = isSmallScreen ? 150 : 210;

  let spawned = 0;
  let livePopups = [];
  let spawnTimer = null;

  /* ---------------- Pop sound (synthesized, no audio file needed) ---------------- */
  let audioCtx = null;
  function unlockAudio() {
    if (!audioCtx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (AC) audioCtx = new AC();
    }
    if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
  }

  function playPop() {
    if (!audioCtx) return;
    const now = audioCtx.currentTime;

    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain);
    gain.connect(audioCtx.destination);

    // Quick upward "boop" — high-pitched cartoon pop, pitch varies per popup
    const startFreq = 480 + Math.random() * 260;
    osc.type = 'sine';
    osc.frequency.setValueAtTime(startFreq, now);
    osc.frequency.exponentialRampToValueAtTime(startFreq * 2.4, now + 0.07);

    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.22, now + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.13);

    osc.start(now);
    osc.stop(now + 0.14);
  }

  function playSweep() {
    // One low "whoosh" when the flood begins
    if (!audioCtx) return;
    const now = audioCtx.currentTime;
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(120, now);
    osc.frequency.exponentialRampToValueAtTime(60, now + 0.4);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.15, now + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.45);
    osc.start(now);
    osc.stop(now + 0.45);
  }

  function playCloseBlip() {
    if (!audioCtx) return;
    const now = audioCtx.currentTime;
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.type = 'sine';
    osc.frequency.setValueAtTime(500, now);
    osc.frequency.exponentialRampToValueAtTime(220, now + 0.09);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.14, now + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.1);
    osc.start(now);
    osc.stop(now + 0.1);
  }

  function playChime() {
    if (!audioCtx) return;
    const now = audioCtx.currentTime;
    [660, 880, 1100].forEach((freq, i) => {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.type = 'sine';
      const start = now + i * 0.09;
      osc.frequency.setValueAtTime(freq, start);
      gain.gain.setValueAtTime(0.0001, start);
      gain.gain.exponentialRampToValueAtTime(0.18, start + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.3);
      osc.start(start);
      osc.stop(start + 0.3);
    });
  }

  function spawnPopup() {
    const frag = popupTemplate.content.cloneNode(true);
    const popup = frag.querySelector('.popup');
    const titleEl = frag.querySelector('.popup-title');
    const closeEl = frag.querySelector('.popup-close');
    const imgWrap = frag.querySelector('.popup-img-wrap');
    const imgEl = frag.querySelector('.popup-img');
    const captionEl = frag.querySelector('.popup-caption');

    const caption = randomCaption();
    const seed = `${Date.now()}_${spawned}_${Math.floor(Math.random() * 100000)}`;

    titleEl.textContent = `good_morning_${spawned + 1}.jpg`;
    captionEl.textContent = caption;
    imgEl.src = pickImageSrc(caption, seed);
    imgEl.addEventListener('error', () => imgWrap.classList.add('img-failed'));

    const maxX = Math.max(0, window.innerWidth - BOX_W);
    const maxY = Math.max(0, window.innerHeight - BOX_H);
    const x = Math.random() * maxX;
    const y = Math.random() * maxY;
    const rot = (Math.random() * 26 - 13).toFixed(1);

    popup.style.left = x + 'px';
    popup.style.top = y + 'px';
    popup.style.setProperty('--rot', rot + 'deg');
    popup.style.zIndex = 10 + spawned;

    closeEl.addEventListener('click', (e) => {
      e.stopPropagation();
      playCloseBlip();
      popup.style.transition = 'transform 0.2s ease, opacity 0.2s ease';
      popup.style.transform = `scale(0) rotate(${rot}deg)`;
      popup.style.opacity = '0';
      setTimeout(() => popup.remove(), 200);
      livePopups = livePopups.filter((p) => p !== popup);
    });

    popupLayer.appendChild(popup);
    livePopups.push(popup);
    spawned++;
    playPop();
  }

  function startFlood() {
    unlockAudio();
    landing.style.display = 'none';
    popupLayer.hidden = false;
    popupLayer.innerHTML = '';
    livePopups = [];
    spawned = 0;
    cleanupBtn.hidden = true;

    playSweep();
    document.body.classList.add('shaking');
    setTimeout(() => document.body.classList.remove('shaking'), 800);

    spawnTimer = setInterval(() => {
      const batch = Math.random() < 0.5 ? 2 : 3;
      for (let i = 0; i < batch && spawned < TOTAL_POPUPS; i++) spawnPopup();
      if (spawned >= TOTAL_POPUPS) {
        clearInterval(spawnTimer);
        setTimeout(() => { cleanupBtn.hidden = false; }, 400);
      }
    }, 160);
  }

  triggerBtn.addEventListener('click', startFlood);

  cleanupBtn.addEventListener('click', () => {
    livePopups.forEach((popup, i) => {
      setTimeout(() => {
        popup.style.transition = 'transform 0.3s ease, opacity 0.3s ease';
        popup.style.transform = 'scale(0) rotate(0deg)';
        popup.style.opacity = '0';
      }, i * 12);
    });
    cleanupBtn.hidden = true;
    playChime();
    setTimeout(() => {
      popupLayer.hidden = true;
      popupLayer.innerHTML = '';
      landing.style.display = 'flex';
    }, 700);
  });

});
